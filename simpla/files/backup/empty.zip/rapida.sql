/* $skipcreate is true. Truncate table s_blog */
TRUNCATE TABLE `s_blog`;
/* Data for table s_blog */
;
/* $skipcreate is true. Truncate table s_brands */
TRUNCATE TABLE `s_brands`;
/* Data for table s_brands */
;
/* $skipcreate is true. Truncate table s_cache_integer */
TRUNCATE TABLE `s_cache_integer`;
/* $skipdata is true. Data skipped s_cache_integer */
/* $skipcreate is true. Truncate table s_categories */
TRUNCATE TABLE `s_categories`;
/* Data for table s_categories */
;
/* $skipcreate is true. Truncate table s_categories_features */
TRUNCATE TABLE `s_categories_features`;
/* Data for table s_categories_features */
INSERT INTO `s_categories_features` (`category_id`,`feature_id`) VALUES
(1, 1);
/* $skipcreate is true. Truncate table s_comments */
TRUNCATE TABLE `s_comments`;
/* Data for table s_comments */
;
/* $skipcreate is true. Truncate table s_coupons */
TRUNCATE TABLE `s_coupons`;
/* Data for table s_coupons */
;
/* $skipcreate is true. Truncate table s_currencies */
TRUNCATE TABLE `s_currencies`;
/* Data for table s_currencies */
INSERT INTO `s_currencies` (`id`,`name`,`sign`,`code`,`rate`,`cents`,`pos`,`enabled`) VALUES
(1, 'RUR', 'RUR', 'RUR', '1', 0, 0, 1),
(2, 'USD', 'USD', 'USD', '0.0166667', 2, 1, 1),
(3, 'EUR', 'EUR', 'EUR', '0.0142857', 2, 2, 1);
/* $skipcreate is true. Truncate table s_delivery */
TRUNCATE TABLE `s_delivery`;
/* Data for table s_delivery */
;
/* $skipcreate is true. Truncate table s_delivery_payment */
TRUNCATE TABLE `s_delivery_payment`;
/* Data for table s_delivery_payment */
;
/* $skipcreate is true. Truncate table s_features */
TRUNCATE TABLE `s_features`;
/* Data for table s_features */
INSERT INTO `s_features` (`id`,`name`,`gid`,`trans`,`trans2`,`pos`,`in_filter`,`tpl`,`visible`) VALUES
(1, 'тестовое', 0, 'testovoe', '', 0, 0, 0, 0);
/* $skipcreate is true. Truncate table s_feedback */
TRUNCATE TABLE `s_feedback`;
/* Data for table s_feedback */
;
/* $skipcreate is true. Truncate table s_groups */
TRUNCATE TABLE `s_groups`;
/* Data for table s_groups */
;
/* $skipcreate is true. Truncate table s_img_blog */
TRUNCATE TABLE `s_img_blog`;
/* Data for table s_img_blog */
;
/* $skipcreate is true. Truncate table s_img_categories */
TRUNCATE TABLE `s_img_categories`;
/* Data for table s_img_categories */
INSERT INTO `s_img_categories` (`id`,`item_id`,`basename`,`pos`) VALUES
(1, 193, '815183d053fc018be591f0e28cff9c04.jpg', 0),
(7, 2, '9fccd9155ac877d6b975ab5266c74e01.jpg', 0),
(8, 2, '815183d053fc018be591f0e28cff9c04.jpg', 1),
(9, 9, '815183d053fc018be591f0e28cff9c04.jpg', 0);
/* $skipcreate is true. Truncate table s_img_products */
TRUNCATE TABLE `s_img_products`;
/* Data for table s_img_products */
INSERT INTO `s_img_products` (`id`,`item_id`,`basename`,`pos`) VALUES
(2, 1, '2ff0198a81469a6f381425ae75f979c8.jpg', 0);
/* $skipcreate is true. Truncate table s_labels */
TRUNCATE TABLE `s_labels`;
/* Data for table s_labels */
INSERT INTO `s_labels` (`id`,`name`,`color`,`pos`) VALUES
(1, 'новый', '3247ad', 1);
/* $skipcreate is true. Truncate table s_menu */
TRUNCATE TABLE `s_menu`;
/* Data for table s_menu */
INSERT INTO `s_menu` (`id`,`name`,`pos`) VALUES
(1, 'Основное меню', 0),
(2, 'Другие страницы', 1);
/* $skipcreate is true. Truncate table s_options */
TRUNCATE TABLE `s_options`;
/* Data for table s_options */
;
/* $skipcreate is true. Truncate table s_options_groups */
TRUNCATE TABLE `s_options_groups`;
/* Data for table s_options_groups */
INSERT INTO `s_options_groups` (`id`,`name`,`pos`) VALUES
(1, 'основные ', 1),
(2, 'второстепенные ', 2);
/* $skipcreate is true. Truncate table s_options_uniq */
TRUNCATE TABLE `s_options_uniq`;
/* Data for table s_options_uniq */
;
/* $skipcreate is true. Truncate table s_orders */
TRUNCATE TABLE `s_orders`;
/* Data for table s_orders */
;
/* $skipcreate is true. Truncate table s_orders_labels */
TRUNCATE TABLE `s_orders_labels`;
/* Data for table s_orders_labels */
;
/* $skipcreate is true. Truncate table s_pages */
TRUNCATE TABLE `s_pages`;
/* Data for table s_pages */
;
/* $skipcreate is true. Truncate table s_payment_methods */
TRUNCATE TABLE `s_payment_methods`;
/* Data for table s_payment_methods */
INSERT INTO `s_payment_methods` (`id`,`module`,`name`,`description`,`currency_id`,`settings`,`enabled`,`pos`) VALUES
(1, 'Receipt', 'Квитанция', '<p>Вы можете распечатать квитанцию и оплатить её в любом отделении банка.</p>', 2, 'a:10:{s:9:\"recipient\";s:65:\"ООО \"Великолепный интернет-магазин\"\";s:3:\"inn\";s:5:\"12345\";s:7:\"account\";s:6:\"223456\";s:4:\"bank\";s:18:\"Альфабанк\";s:3:\"bik\";s:6:\"556677\";s:21:\"correspondent_account\";s:11:\"77777755555\";s:8:\"banknote\";s:7:\"руб.\";s:5:\"pense\";s:7:\"коп.\";s:5:\"purse\";s:2:\"ru\";s:10:\"secret_key\";s:0:\"\";}', 1, 2),
(2, 'Webmoney', 'Webmoney wmz', '<p><span></span></p><div><p>Оплата через платежную систему&nbsp;<a href=\"http://www.webmoney.ru\">WebMoney</a>. У вас должен быть счет в этой системе для того, чтобы произвести оплату. Сразу после оформления заказа вы будете перенаправлены на специальную страницу системы WebMoney, где сможете произвести платеж в титульных знаках WMZ.</p></div><p>&nbsp;</p>', 3, 'a:10:{s:9:\"recipient\";s:0:\"\";s:3:\"inn\";s:0:\"\";s:7:\"account\";s:0:\"\";s:4:\"bank\";s:0:\"\";s:3:\"bik\";s:0:\"\";s:21:\"correspondent_account\";s:0:\"\";s:8:\"banknote\";s:7:\"руб.\";s:5:\"pense\";s:0:\"\";s:5:\"purse\";s:13:\"Z111111111111\";s:10:\"secret_key\";s:13:\"testsecretkey\";}', 1, 1),
(3, 'Robokassa', 'Робокасса', '<p><span>RBK Money &ndash; это электронная платежная система, с помощью которой Вы сможете совершать платежи с персонального компьютера, коммуникатора или мобильного телефона.</span></p>', 3, 'a:14:{s:9:\"recipient\";s:0:\"\";s:3:\"inn\";s:0:\"\";s:7:\"account\";s:0:\"\";s:4:\"bank\";s:0:\"\";s:3:\"bik\";s:0:\"\";s:21:\"correspondent_account\";s:0:\"\";s:8:\"banknote\";s:0:\"\";s:5:\"pense\";s:0:\"\";s:5:\"login\";s:0:\"\";s:9:\"password1\";s:0:\"\";s:9:\"password2\";s:0:\"\";s:8:\"language\";s:2:\"ru\";s:5:\"purse\";s:0:\"\";s:10:\"secret_key\";s:0:\"\";}', 1, 3),
(4, 'Paypal', 'PayPal', '<p>Совершайте покупки безопасно, без раскрытия информации о своей кредитной карте. PayPal защитит вас, если возникнут проблемы с покупкой</p>', 1, 'a:16:{s:8:\"business\";s:0:\"\";s:4:\"mode\";s:7:\"sandbox\";s:9:\"recipient\";s:0:\"\";s:3:\"inn\";s:0:\"\";s:7:\"account\";s:0:\"\";s:4:\"bank\";s:0:\"\";s:3:\"bik\";s:0:\"\";s:21:\"correspondent_account\";s:0:\"\";s:8:\"banknote\";s:0:\"\";s:5:\"pense\";s:0:\"\";s:5:\"login\";s:0:\"\";s:9:\"password1\";s:0:\"\";s:9:\"password2\";s:0:\"\";s:8:\"language\";s:2:\"ru\";s:5:\"purse\";s:0:\"\";s:10:\"secret_key\";s:0:\"\";}', 1, 4),
(5, 'Interkassa', 'Оплата через Интеркассу', '<p><span>Это удобный в использовании сервис, подключение к которому позволит Интернет-магазинам, веб-сайтам и прочим торговым площадкам принимать все возможные формы оплаты в максимально короткие сроки.</span></p>', 2, 'a:2:{s:18:\"interkassa_shop_id\";s:3:\"123\";s:21:\"interkassa_secret_key\";s:3:\"123\";}', 1, 5),
(6, 'Liqpay', 'Оплата картой через Liqpay.com', '<p><span>Благодаря своей открытости и универсальности LiqPAY стремительно интегрируется со многими платежными системами и платформами и становится стандартом платежных операций.</span></p>', 2, 'a:5:{s:9:\"liqpay_id\";s:3:\"123\";s:11:\"liqpay_sign\";s:3:\"123\";s:12:\"pay_way_card\";s:1:\"1\";s:14:\"pay_way_liqpay\";s:1:\"1\";s:15:\"pay_way_delayed\";s:1:\"1\";}', 1, 6),
(7, 'Pay2Pay', 'Оплата через Pay2Pay', '<p>Универсальный платежный сервис Pay2Pay призван облегчить и максимально упростить процесс приема электронных платежей на Вашем сайте. Мы открыты для всего нового и сверхсовременного.</p>', 2, 'a:5:{s:18:\"pay2pay_merchantid\";s:3:\"123\";s:14:\"pay2pay_secret\";s:3:\"123\";s:14:\"pay2pay_hidden\";s:3:\"123\";s:15:\"pay2pay_paymode\";s:3:\"123\";s:16:\"pay2pay_testmode\";s:1:\"1\";}', 1, 7),
(8, 'Qiwi', 'Оплатить через QIWI', '<p><span>QIWI &mdash; удобный сервис для оплаты повседневных услуг</span></p>', 2, 'a:2:{s:10:\"qiwi_login\";s:3:\"123\";s:13:\"qiwi_password\";s:3:\"123\";}', 1, 8);
/* $skipcreate is true. Truncate table s_products */
TRUNCATE TABLE `s_products`;
/* Data for table s_products */
;
/* $skipcreate is true. Truncate table s_products_categories */
TRUNCATE TABLE `s_products_categories`;
/* Data for table s_products_categories */
INSERT INTO `s_products_categories` (`product_id`,`category_id`) VALUES
(1, 1);
/* $skipcreate is true. Truncate table s_purchases */
TRUNCATE TABLE `s_purchases`;
/* Data for table s_purchases */
INSERT INTO `s_purchases` (`id`,`order_id`,`product_id`,`variant_id`,`product_name`,`variant_name`,`price`,`amount`,`sku`) VALUES
(1, 1, 1, 1, 'test', '', 4354.00, 3, '1');
/* $skipcreate is true. Truncate table s_queue */
TRUNCATE TABLE `s_queue`;
/* $skipdata is true. Data skipped s_queue */
/* $skipcreate is true. Truncate table s_queue_full */
TRUNCATE TABLE `s_queue_full`;
/* $skipdata is true. Data skipped s_queue_full */
/* $skipcreate is true. Truncate table s_related_products */
TRUNCATE TABLE `s_related_products`;
/* Data for table s_related_products */
;
/* $skipcreate is true. Truncate table s_settings */
TRUNCATE TABLE `s_settings`;
/* Data for table s_settings */
INSERT INTO `s_settings` (`setting_id`,`name`,`value`) VALUES
(1, 'theme', 'default'),
(2, 'site_name', 'site'),
(3, 'company_name', 'site'),
(4, 'date_format', 'd.m.Y'),
(5, 'admin_email', 'site@site.si'),
(6, 'order_email', 'site@site.si'),
(7, 'comment_email', 'site@site.si'),
(8, 'notify_from_email', 'site@site.si'),
(9, 'decimals_point', '.'),
(10, 'thousands_separator', ' '),
(11, 'products_num', '24'),
(12, 'products_num_admin', '24'),
(13, 'max_order_amount', '100'),
(14, 'units', 'ед.'),
(15, 'phone', '');
/* $skipcreate is true. Truncate table s_slider */
TRUNCATE TABLE `s_slider`;
/* Data for table s_slider */
;
/* $skipcreate is true. Truncate table s_text_options */
TRUNCATE TABLE `s_text_options`;
/* Data for table s_text_options */
;
/* $skipcreate is true. Truncate table s_users */
TRUNCATE TABLE `s_users`;
/* Data for table s_users */
INSERT INTO `s_users` (`id`,`email`,`password`,`name`,`group_id`,`enabled`,`admin`,`perm`,`last_ip`,`last_login`,`created`) VALUES
(1, 'admin@admin.ad', '5f6b179e0034e20383dfe8942f59cda6', 'admin@admin.ad', 0, 1, 1, '0:1:2:3:4:5:6:7:8:9:10:11:12:13:14:15:16:17:18:19:20:21:22:23', '151.66.102.24', '2018-03-26 20:20:35', '2017-11-12 06:08:40');
/* $skipcreate is true. Truncate table s_variants */
TRUNCATE TABLE `s_variants`;
/* Data for table s_variants */
INSERT INTO `s_variants` (`id`,`product_id`,`sku`,`name`,`price`,`price1`,`price2`,`price3`,`old_price`,`stock`,`preorder`,`pos`) VALUES
(1, 1, '1', '', 4354.00, 354.00, 5.00, 2.00, 200.00, 999, 0, 0);
